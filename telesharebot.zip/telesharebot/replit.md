# Telegram File Sharing Bot

## Overview

A Telegram bot that allows users to share files via unique links. Users send files to the bot, which stores them and generates shareable codes. Other users can retrieve files using these codes through the bot's start command with a deep link parameter.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Components

**Bot Framework**: Uses python-telegram-bot library for Telegram API integration. Handles commands (/start) and message handlers for file uploads.

**Data Storage**: SQLite database (`files.db`) with a simple schema:
- `files` table: stores mapping between unique codes and Telegram file IDs
- Uses Telegram's file storage (files are stored on Telegram servers, bot stores references)

### Design Decisions

**File Storage Strategy**: Instead of storing actual file contents, the bot stores Telegram's `file_id`. This leverages Telegram's CDN and avoids local storage limitations.

**Code Generation**: Random 8-character alphanumeric codes for file identification. Simple but effective for moderate usage.

**Database Choice**: SQLite for simplicity and zero configuration. Suitable for single-instance deployment but would need migration to PostgreSQL for production scaling.

### Entry Point

- `main.py`: Single-file application containing all bot logic, database setup, and handlers

## External Dependencies

### APIs and Services

- **Telegram Bot API**: Core functionality via python-telegram-bot library
- Bot token configured via `BOT_TOKEN` environment variable

### Python Packages

- `python-telegram-bot`: Telegram Bot API wrapper
- `sqlite3`: Built-in database driver

### Environment Variables

- `BOT_TOKEN`: Telegram bot authentication token (required)